

<?php


session_start();
   


require '../database.php';

if (isset($_POST["login"])) {
    $email = $_POST["email"];
    $password = $_POST["password"];

    // Prepare and bind
    $stmt = $conn->prepare("SELECT * FROM studentsmasterlist WHERE EMAIL = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    if ($result->num_rows > 0) {
        if ($password == $row["STUDENT_ID"]) { // It's recommended to use password hashing
           
            $_SESSION["login"] = "true";
            $_SESSION["id"] = $row["ID"];
            $_SESSION["email"] = $email; // Store email in session
            $_SESSION["password"] = $password; // Store password in session (not recommended, use for demo purposes only)
           
            header("Location: students.php");
            
            die();
        } else {
            $error_message = "Password does not match";
        }
    } else {
        $error_message = "Invalid email or password";
    }

    // Close the statement and the connection
    $stmt->close();
    $conn->close();
}
?>








<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sudentlogin,php</title>
    
    <link
    href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;500;700;900&family=Sen:wght@400;700;800&display=swap"
    rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">

<!-- FOR LOGIN FORN ANIMATION-->
    <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>

    <!--FOR UNICONS-->
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css" />
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url("../images/rmmcbg.jpg");
            background-repeat: no-repeat;
            background-size: cover;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;   
            height: 100vh;
        }
        /* FOR HEADER*/
        .header{
            position:fixed;
            width:100%;
            height:10vh;
            overflow: hidden;
            background-color:white;
            margin-top:0px;
        }
        /*FOR LOGO CONTAINER*/
        .logoCon{
            float:left;
            width:auto;
            height:auto;
        }
        .logo{
            height:10vh;
            width:25vw;
        }
        /*FOR STUDENT AND ADMIN BUTTON*/
        .studentAdminCon{
            width:auto;
            height:auto;     
            display:inline-block;       
            text-align:center; 
            margin:0px 0px 0px 10vw;
            padding:15px 15px 15px 15px; 
            
        }
        .studentButton{
            display:inline-block;
            

        }
        .adminButton{
            display:inline-block;   
        }
        .studentAdminCon ul {
            list-style:none;
        }
        .studentAdminCon ul li a{
            text-decoration:none;
            margin-left:10px;
            padding:10px;
            color:rgb(4, 64, 177);
            border-radius:10px;
            font-weight: bold;
            font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
            
        }
        .studentAdminCon ul li a:hover{
            background-color:antiquewhite;
        }
        /* FOR LOGIN FORM*/
        .loginFormCon{
            margin-top:15vh;
            width:40vw;
            height:70vh;
            justify-content: center;
            text-align:center;
            box-shadow: 0px 10px 20px rgba(0, 0, 0,10);
            border-radius: 10px;
            background-color:rgba(192, 192, 192, 0.76);
        }
        .logintxt{
            text-align:center;
            font-size:35px;
            font-weight:bold;
            font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
            margin:20px 0px 0px 0px ;
        }
        .usernameCon{
            margin-top:10vh;
            width:auto;
            height:auto;
            justify-content: center;
        }
        .usernameCon label{
            display:block;

        }
        #email{
            height:40px;
            width:20vw;
            border-radius:10px;
            margin-top:10px;
        }
        .passwordCon{
            margin-top:40px;
        }
        .passwordCon label{
            display:block;
        }
        #password{
            height:40px;
            width:20vw;
            border-radius:10px;
            margin-top:10px;
            border:0px;
        }
        #login{
            width:11vw;
            height:40px;
            margin-top:80px;
            border-radius:15px;

        }





        .registerCon{
            margin:5vh 0px 0px 0px;
            width:20vw;    
        }
        .registerCon p a{
            color:blue;
        }


    </style>

   




</head>
<body>
    <div class="header">
        <div class="logoCon">
            <a href="../main.html"><image class="logo"src="../images/rmmcLogo.png"></image></a>
                        
        </div>
        <div class="studentAdminCon">       
            <ul >
                <li class="studentButton"><a href="../students/studentlogin.php">STUDENT-LOGIN</a></li>                
                <li class="adminButton"><a href="../administrator/adminlogin.php">ADMINISTRATOR</a></li>
            </ul>   
        </div>
                        
    </div>

    <div class="loginFormCon">
        <div class="logintxt">STUDENT LOGIN</div>
        <form action="studentlogin.php"  method="post">
            <div class="usernameCon">
                <label>Email</label>
                <input type="email" name="email" id="email" required>
            </div>
            <div class="passwordCon">
                <label>Password</label>
                <input type="password" name="password" id="password" required>
            </div>
            <input type="submit" name="login" id="login" value="Login">

        </form>
        <div class="registerCon">
            <p>Not yet register?<a href="../registration/registrationForm.html">Register Here</a></p>
        </div>
    </div>



 
    





<script src="home.js"></script>
</body>
</html>