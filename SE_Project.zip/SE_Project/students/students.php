<?php
session_start();

// Redirect to login page if not logged in
if (!isset($_SESSION["login"])) {
    header("Location: studentlogin.php");
    exit;
}

// Access email and password
$email = $_SESSION["email"];
$password = $_SESSION["password"];

// Database connection (adjust with your own database details)
require '../database.php';

// Query to retrieve additional data from studentsmasterlist
$stmt = $conn->prepare("SELECT LASTNAME, FIRSTNAME, MIDDLENAME, STUDENT_ID, COURSE, YEAR FROM studentsmasterlist WHERE EMAIL = ? ");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Fetch data
    $row = $result->fetch_assoc();
    $lastname = $row['LASTNAME'];
    $firstname = $row['FIRSTNAME'];
    $middlename = $row['MIDDLENAME'];
    $student_id = $row['STUDENT_ID'];
    $course = $row['COURSE'];
    $year = $row['YEAR'];
} else {
    // Handle case where user data is not found
    $lastname = "N/A";
    $firstname = "N/A";
    $middlename = "N/A";
    $student_id = "N/A";
    $course = "N/A";
    $year = "N/A";
}

$stmt->close();


// Check if year and semester are set
if (isset($_GET['year']) && isset($_GET['semester'])) {
    $year = $_GET['year'];
    $semester = $_GET['semester'];

    if($course == "BS Computer Science"){
        // Query to retrieve data from bscssubjects
        $stmt = $conn->prepare("SELECT CN, SUBJECT, TERM, DESCRIPTIVE_TITTLE, UNIT, DAY, ROOM, TIME, GRADE FROM bscssubjects WHERE YEAR = ? AND SEMESTER = ?");
        $stmt->bind_param("ii", $year, $semester);
        $stmt->execute();
        $subjects_result = $stmt->get_result();
    }
    else if($course =="BS Information Technology"){
        // Query to retrieve data from bscssubjects
        $stmt = $conn->prepare("SELECT CN, SUBJECT, TERM, DESCRIPTIVE_TITTLE, UNIT, DAY, ROOM, TIME, GRADE FROM itsubjects WHERE YEAR = ? AND SEMESTER = ?");
        $stmt->bind_param("ii", $year, $semester);
        $stmt->execute();
        $subjects_result = $stmt->get_result();

    }
    else if($course =="Associate in Computer Technology"){
        // Query to retrieve data from bscssubjects
        $stmt = $conn->prepare("SELECT CN, SUBJECT, TERM, DESCRIPTIVE_TITTLE, UNIT, DAY, ROOM, TIME, GRADE FROM actubjects WHERE YEAR = ? AND SEMESTER = ?");
        $stmt->bind_param("ii", $year, $semester);
        $stmt->execute();
        $subjects_result = $stmt->get_result();

    }
    else if($course =="Bachelor in Library and Information science"){
        // Query to retrieve data from bscssubjects
        $stmt = $conn->prepare("SELECT CN, SUBJECT, TERM, DESCRIPTIVE_TITTLE, UNIT, DAY, ROOM, TIME, GRADE FROM blissubjects WHERE YEAR = ? AND SEMESTER = ?");
        $stmt->bind_param("ii", $year, $semester);
        $stmt->execute();
        $subjects_result = $stmt->get_result();

    }

    

    




} else {
    $subjects_result = false;
}



$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet"  href="students.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <title>students.php</title>
    <style>
        /*FOR STUDENT ACCOUNT INTERFACE*/

        .profile_header{
            background-image:linear-gradient(rgb(8, 40, 89) ,rgb(66, 165, 245)40%,rgb(144, 202, 249),rgb(187, 222, 251),white 100%);
            height:450px;
            width:100%;
            margin:0px; 

        }
        .profName_container{
            margin: 10px 0px 0px 25%;
            width:50%; 
            background-color:rgb(64, 101, 159);
            text-align:center;
            box-shadow: 5px 5px 10px  rgba(0, 0, 0,10);
        }
        .profilepic_container{
            height:200px;
            width:200px;
            background-color:rgba(255, 255, 255, 0);
            margin:0px 0px 0px 36% ;
            border-radius:50%;
            display:block; 
            
            
        }
        .profile_header .profName_container .name_container h3{
            font-weight:bold;
            font-size:30px;   
        }
        .profile_header .profName_container .id_container{
            background-color:rgb(64, 101, 159);
            
            height:30px;
            width:90%;
            margin:0px 0px 0px 30px;
            text-align:left;
        }
        .profile_header .profName_container .course_container{
            background-color:rgb(64, 101, 159);
            
            height:30px;
            width:90%;
            margin:5px 0px 0px 30px;
            text-align:left;
        }
        .profile_header .profName_container .year_container{
            background-color:rgb(64, 101, 159);
            
            height:30px;
            width:90%;
            margin:5px 0px 10px 30px;
            text-align:left;
        }


        .profilepic{
            width:15vw ;
        }
        .name_container{
            font-weight: bold;
            font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
        }
        .id_container{
            height:30px;
            width:90%;
            font-size:20px;
            font-weight: bold;
            font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
        }
        .course_container{
            height:30px;
            width:90%;
            font-size:20px;
            font-weight: bold;
            font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;

        }
        .year_container{
            height:30px;
            width:90%;
            font-size:20px;
            font-weight: bold;
            font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;

        }

        /**FOR YEAR AND SEMESTER FORM */
        .formCon{
            margin:auto;
            width:33vw;
            height:auto;
            
            padding:10px ;
            background-color:rgb(64, 101, 159);
        }
        .yearCon{
            display:inline-block;
        }
        .yearCon label{
            font-size: 20px;
            font-weight: bold;
        }
        .semesterCon{
            margin: 0px 0px 0px 2vw;
            display:inline-block;
        }
        .semesterCon label{
            font-size: 20px;
            font-weight: bold;
        }
        .year{
            width:5vw;
        }
        .semester{
            width:5vw;

        }
        .submit{
            margin-left:3vw;
            display:inline-block;
            width:5vw;
            height:3vh;
        }


        /**SUBJECT TABLE */
        .subjectsTable{
            width:70vw;
            height:40vh;
            border:1px solid;
            text-align: center;
            margin-top:10vh ;
            margin-left:auto;
            margin-right:auto;
            background-color: rgb(176, 190, 197);
            box-shadow: 1px 10px 20px  rgba(0, 0, 0,10);
        }

        


        /*FOR LOG OUT*/
        #logout_button{
            width:15vw;
            padding:10px;
            height:auto;
            margin: 20vh 0px 10vh 42vw;
            font-weight:bold;
            font-size:20px;
           

        }
        #logout_button:hover{
            background-color:rgb(182, 0, 0);
        }
        #logout{
            text-decoration: none;
        }
        
        
    </style>
</head>
<body>
    <div>
        <div class="profile_header"> 
            <div class="profName_container">
                
                <div class="profilepic_container">
                    <image src="../images/user.png" class="profilepic"></image>
                </div>
                <div class="name_container">
                    <h3><?php echo "$lastname  $firstname $middlename"; ?></h3>
                </div>
                <div class="id_container">
                    <a>ID : <?php echo $student_id; ?></a>
                </div>
                <div class="course_container">
                    <a>COURSE : <?php echo $course; ?></a>
                </div>
                <div class="year_container">
                    <a>YEAR : <?php echo $year; ?></a>
                </div>
                <hr>
            </div>                      
        </div>

        <div class="formCon">
            <form>
                <div class="yearCon">
                    <label>Year :</label>
                    <select name="year" class="year" id="year">
                        <option></option>
                        <option>1</option>
                        <option>2</option>
                        <option>3</option>
                        <option>4</option>
                    </select>
                </div>
                <div class="semesterCon">
                <label>Semester :</label>
                    <select name="semester" class="semester" id= "semester">
                        <option></option>
                        <option>1</option>
                        <option>2</option>                        
                    </select>

                </div>
                <input type="submit" name="submit" class="submit" id="submit"></form>
            </form>
        </div>



        <?php if ($subjects_result && $subjects_result->num_rows > 0): ?>
            
        <table class="subjectsTable">
            <thead>
                <tr>
                    <th>CN</th>
                    <th>Subject</th>
                    <th>Term</th>
                    <th>Descriptive Title</th>
                    <th>Unit</th>
                    <th>Day</th>
                    <th>Room</th>
                    <th>Time</th>
                    <th>Grade</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $subjects_result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['CN']); ?></td>
                    <td><?php echo htmlspecialchars($row['SUBJECT']); ?></td>
                    <td><?php echo htmlspecialchars($row['TERM']); ?></td>
                    <td><?php echo htmlspecialchars($row['DESCRIPTIVE_TITTLE']); ?></td>
                    <td><?php echo htmlspecialchars($row['UNIT']); ?></td>
                    <td><?php echo htmlspecialchars($row['DAY']); ?></td>
                    <td><?php echo htmlspecialchars($row['ROOM']); ?></td>
                    <td><?php echo htmlspecialchars($row['TIME']); ?></td>
                    <td><?php echo htmlspecialchars($row['GRADE']); ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <?php else: ?>
        <p>No subjects found for the selected year and semester.</p>
        <?php endif; ?>

        <div class="iframeCon">
            <iframe src="https://rmmc.instructure.com/login/canvas" title="this is nothing" width="1400px" height="500px" margin-top="50px"></iframe>
        </div>

        

        <button id="logout_button"><a href="logoutstudent.php" id="logout">Log Out</a></button>
    </div>
    
</body>
</html>
