const ball = document.querySelector(".toggle-ball");
const items = document.querySelectorAll(
  ".header,.toggle,body,.tag,.containerOne,.logo"
);

ball.addEventListener("click", () => {
  items.forEach((item) => {
    item.classList.toggle("active");
  });
  ball.classList.toggle("active");
});

 