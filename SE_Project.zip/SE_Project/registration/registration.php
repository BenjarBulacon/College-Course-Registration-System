<?php

echo "<style>
.resultCon {
    background-color: #f9f9f9;
    border: 1px solid #ddd;
    padding: 20px;
    margin: 0px 0px 0px 20vw;
    width:60vw;
    font-family: Arial, sans-serif;
    text-align:center;
}
.resultCon .txt {
    margin-bottom: 10px;
    font-size:20px;
}
.resultCon .email {
    font-weight: bold;
    margin:10px 0px 20px 0px ;
}
.okbutton{
    margin-top:30px ;
    padding:10px;
    border-radius:20px;
    color:white;
    background-color:#0011AD;
}
</style>";

include
 '../database.php';

$lastname = $_POST["lastname"];
$firstname = $_POST["firstname"];
$midname = $_POST["midname"];
$address = $_POST["address"];
$birthdate = $_POST["birthdate"];
$gender = $_POST["gender"];
$email = $_POST["email"];
$course = $_POST["course"];
$year = $_POST["year"];
$guardian = $_POST["guardian"];
$contact = $_POST["contact"];

$sql = "INSERT INTO enrollees (LASTNAME, FIRSTNAME, MIDDLENAME, GENDER, BIRTHDATE, EMAIL, COURSE, YEAR, ADDRESS, GUARDIAN, CONTACT) 
        VALUES ('$lastname', '$firstname', '$midname', '$gender', '$birthdate', '$email', '$course', '$year', '$address', '$guardian', '$contact')";

if ($conn->query($sql) === TRUE) {
    // Assuming Gmail is unique, use it to verify the insertion
    $sql = "SELECT EMAIL FROM enrollees WHERE EMAIL = '$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $email = $row['EMAIL'];

        echo "<div class='resultCon'>";
        echo "<div class='txt'>Your form has been successfully submitted. Please wait for approval, which will be sent to your email.</div>";
        echo "<div class='email'>Email: $email</div>";
        echo "<a href=../main.html class='okbutton'>OK</a>";
        echo "</div>";

    } else {
        echo "Error retrieving email.";
    }
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close the connection
mysqli_close($conn);
?>
