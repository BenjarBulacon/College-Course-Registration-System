<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Subjects</title>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" 
    integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />

    <style>
        body {
            margin: 0;
            padding: 0;
            
            font-family: Arial, sans-serif;
        }

        /* FOR SIDE NAVIGATION */
        .sideNavCon {
            height: 100vh;
            width: 73px;
            background-color: rgb(0, 9, 92);   
            position: fixed;
            z-index: 10;
            top: 0;
            left: 0;
            box-shadow: 3px 0px 10px rgba(0, 0, 0, 10);
            overflow: hidden; 
            transition: width 0.3s ease;     
        }

        .sideNavCon:hover {
            width: 170px;
        }

        .logoCon {
            height: 100px;
            overflow: hidden;
            background-color: rgb(177, 177, 177);
        }

        #iteLogo {
            height: 60px;
            border-radius: 50%;
            margin: 10px 0px 0px 10px;
        }

        #admin {
            font-weight: bold;
            margin: 0px 0px 0px 10px;
        }

        .sideNavbuttons ul {
            list-style: none;
            margin-left: -50px;
        }

        .sideNavbuttons ul li {
            padding: 20px 0px 20px 15px; 
            cursor: pointer;  
            color: rgb(255, 255, 255);
        }

        .sideNavbuttons ul li a {
            color: white;
            padding: 20px 40px 20px 30px;
            width: 100%;   
        }

        .sideNavbuttons ul li a:hover, .sideNavbuttons ul li a.active {
            background-color: rgb(255, 255, 255);
            color: rgb(0, 9, 92);
        }
        .sideNavbuttons ul li a i span{
            font-size:10px;
            margin-left:25px;
        }

        .logoutButton {
            width: 100%;
            margin-top: 30vh;
        }

        /*FOR TOP NAVIGATION */

        .topNavCon {
            width:100vw;
            height:10vh;
            background-color:rgb(236, 239, 250);
            box-shadow: 3px 0px 10px rgba(0, 0, 0,10);
        }

        .subjectstxt{
            font-size:40px;
          
            font-weight:bold;
            font-family: "kainit", sans-serif;
            margin:0px 0px 0px 75px;
            padding:20px;
            display:inline-block;
            
        }
        .addbutton{
            padding:5px 10px 5px 10px;
            background-color: rgb(202, 202, 202);
            color:rgb(0, 42, 180);
            position:relative;
            border-radius: 50%;
            font-size:40px;
            float:right;
            margin-right:5vw;
            margin-top:10px;
            cursor:pointer;            
        }
        .addbutton:hover{
            box-shadow: 0px 0px 3px rgb(0, 9, 92);
            color:rgb(0, 119, 255);
        }

        /*FOR FORM */


        .formCon {
            width: 0;
            height: 0;
            margin: 2vh 0px 0px 7vw;
            background-color: rgba(194, 190, 190, 0.664);
            box-shadow: 0px 10px 20px rgba(0, 0, 0, 10);
            border-radius: 10px;                       
            overflow: hidden;
            z-index: 10;
            transition: width 0.5s, height 0.5s;
            text-align: center;
        }

        .formtitle {
            width: 100%;
            height: 6vh;  
            background-color: white;
            text-align: center;
            font-size: 35px;
            font-weight: bold;
        }

        .exitCon {
            float: right;
            margin-right: 20px;
            cursor: pointer;
        }

        .formCon form {
            padding: 20px 0px 20px 50px;
        }

        .formCon form div {
            display: block;
            margin-top: 20px;
        }

        .formCon form div label {
            display: inline-block;
            font-weight: bold;
            font-size: 20px;
        }

        .formCon form div input {
            display: inline-block;
        }

        #cn, #subject, #term, #capacity, #time, #day {
            width: 30vw;
            height: 4vh;
            border-radius: 5px;
            margin-left: 1vw;
        }

        .schedlbl {
            display: inline-block;
            font-weight: bold;
            font-size: 25px;
            margin-top: 20px;
        }

        .sched {
            margin-left: 10vw;
        }

        .sched div input {
            width: 15vw;
            height: 4vh;
            border-radius: 5px;
        }

        #create {
            padding: 5px;
            font-size: 20px;
            border-radius: 10px;
            font-weight: bold;
            width: 12vw;
            margin: 5vh 0px 0px 15vw;
        }

        .grid-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 20px;
            padding: 20px;
            margin-left:75px;
            background-color:rgb(255, 255, 255);
            width:90vw;
        }

        .grid-item {
            background-color: rgb(100, 181, 246);
            border: 1px solid #ccc;
            padding: 20px;
            text-align: center;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0,0,0,0.1);
            overflow: hidden;
            cursor:pointer;
            transition: box-shadow 0.3s ease, transform 0.3s ease;
        }
        .grid-item:hover{
            box-shadow: 0px 0px 20px rgb(9, 168, 240);
            transform: scale(1.05); /* Increase size on hover */
        }

        .grid-item h3 {
            margin: 10px 0;
            
        }

        .grid-item p {
            margin: 5px 0;
        }
    </style>
</head>
<body>
    <?php
    // Include database connection
    include '../database.php';

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Get form data
        $cn = $_POST['cn'];
        $subject = $_POST['subject'];
        $term = $_POST['term'];
        $capacity = $_POST['capacity'];
        $time = $_POST['time'];   
        $day = $_POST['day'];

        // Prepare and bind
        $stmt = $conn->prepare("INSERT INTO subjects (CN, SUBJECT, TERM, CAPACITY, TIME, DAY) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $cn, $subject, $term, $capacity, $time, $day);

        // Execute the statement
        if ($stmt->execute()) {
            echo "";
        } else {
            echo "Error: " . $stmt->error;
        }

        // Close the statement
        $stmt->close();
    }

    // Fetch subjects from the database
    $result = $conn->query("SELECT * FROM subjects");

    ?>

    <div class="sideNavCon">
        <div class="logoCon">          
            <img src="../images/ITE_logo.png" id="iteLogo" alt="ITE Logo"/>
            <div id="admin">ADMIN</div>
        </div>
        <div class="sideNavbuttons">
            <ul>
                <li><a href="dashboard.php"><i class="fa-solid fa-gauge-high fa-xl" id="dashboardIcon"><span>Dashboard</span></i></a></li>
                <li><a href="courses.php"><i class="fa-solid fa-list fa-xl" id="classesIcon"><span>Courses</span></i></a></li>
                <li><a href="subjects.php"><i class="fa-solid fa-book fa-xl" id="subjectsIcon"><span>Subjects</span></i></a></li>
                <li><a href="students.php"><i class="fa-solid fa-users fa-xl" id="studentsIcon"><span>Students</span></i></a></li>
                <li><a href="enrollees.php"><i class="fa-solid fa-users-between-lines fa-xl" id="enrolleesIcon"><span>Enrollees</span></i></a></li>
                <li class="logoutButton">
                    <a href="logout.php"><i class="fa-solid fa-right-from-bracket fa-xl"><span id="logout">Logout</span></i></a>
                </li>
            </ul>
        </div>
    </div> 

    <div class="subjectsmainCon">
        <div class="topNavCon">
            <div class="subjectstxt">SUBJECTS</div>
            <div class="addbutton" id="addbutton"><i class="fa-solid fa-plus"></i></div>
        </div>    
    </div>

    <div class="formCon" id="formCon">
        <div class="formtitle">CREATE SUBJECT
            <div class="exitCon" id="exitCon"><i class="fa-solid fa-xmark"></i></div>
        </div>
        <form action="subjects.php" method="post">
            <div>
                <label for="cn">CN</label>
                <input type="text" name="cn" id="cn" required>
            </div>
            <div>
                <label for="subject">SUBJECT</label>
                <input type="text" name="subject" id="subject" required>
            </div>
            <div>
                <label for="term">TERM</label>
                <select name="term" id="term">
                    <option>1</option>
                    <option>2</option>
                    <option>3</option>
                </select>
            </div>
            <div>
                <label for="capacity">CAPACITY</label>                
                <input type="text" name="capacity" id="capacity" required>               
            </div>
            <div class="schedlbl">Schedule</div>
            <div class="sched">
                <div>
                    <label for="time">Time:</label>
                    <input type="text" name="time" id="time" placeholder="(e.g. 1:00pm - 4:00pm)" required>
                </div>
                <div>
                    <label for="day">Day:</label>
                    <input type="text" name="day" id="day" placeholder="(e.g F-SAT)" required>
                </div>
            </div>
            <input type="submit" name="create" value="CREATE" id="create">
        </form>
    </div>


    




    <div class="grid-container">
        <?php
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<div class='grid-item'>";
                echo "<h3>" . $row['SUBJECT'] . "</h3>";
                echo "<p>CN: " . $row['CN'] . "</p>";
                echo "<p>Term: " . $row['TERM'] . "</p>";
                echo "<p>Capacity: " . $row['CAPACITY'] . "</p>";
                echo "<p>Time: " . $row['TIME'] . "</p>";
                echo "<p>Day: " . $row['DAY'] . "</p>";
                
                echo "</div>";
            }
        } else {
            echo "<p>No subjects found.</p>";
        }
        $conn->close();
        ?>
    </div>










    <script>
        document.getElementById("addbutton").addEventListener("click", function() {
            document.getElementById("formCon").style.width = "90vw";
            document.getElementById("formCon").style.height = "80vh";
        });

        document.getElementById("exitCon").addEventListener("click", function() {
            document.getElementById("formCon").style.width = "0px";
            document.getElementById("formCon").style.height = "0px";
        });




         









    </script>
</body>
</html>
