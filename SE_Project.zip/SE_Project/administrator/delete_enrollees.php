<?php
include '../database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $studentId = $_POST['student_id'];

    // Use prepared statement to prevent SQL injection
    $stmt = $conn->prepare("DELETE FROM enrollees WHERE EMAIL = ?");
    $stmt->bind_param("s", $studentId);

    if ($stmt->execute()) {
        echo "Student deleted successfully";
    } else {
        echo "Error deleting student: " . $conn->error;
    }

    $stmt->close();
    $conn->close();
}
?>
