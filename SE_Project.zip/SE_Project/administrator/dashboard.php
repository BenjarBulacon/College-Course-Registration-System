
<?php
session_start();
if(!isset($_SESSION["login"])){
    header("Location: adminlogin.php");

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>

    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" 
    integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
     crossorigin="anonymous" referrerpolicy="no-referrer" />

     <style>
        body{
            margin: 0px;
            padding:0px;
            box-sizing: border-box;
        }

        /* FOR SIDE NAVIGATION*/
        .sideNAvCon{
            height:100vh;
            width: 73px;
            background-color:rgb(0, 9, 92);   
            position:fixed;
            z-index:10;
            top: 0;
            left: 0;
            box-shadow: 3px 0px 10px rgba(0, 0, 0,10);
            overflow:hidden; 
            transition: width 0.3s ease;     
        }
        .sideNAvCon:hover{
            width:170px;
            
        }
        .logoCon{
            height:100px;
            overflow:hidden;
            background-color: rgb(16, 61, 130);
        }
        #iteLogo{
            height:60px;
            border-radius:50%;
            margin:10px 0px 0px 10px;
        }
        #admin{
            font-weight:bold;
            font-family: "kainit", sans-serif;
            margin:0px 0px 0px 10px;
        }
        .sideNavbuttons{
            height:auto;
            width:auto;
        }
        .sideNavbuttons ul{
            list-style: none;
            margin-left:-50px;
        }
        .sideNavbuttons ul li{
            padding:20px 0px 20px 15px; 
            cursor: pointer;  
            color:rgb(255, 255, 255);
        }
        .sideNavbuttons ul li a{
            color:white;
            padding:20px 40px 20px 30px ;
            width:100%;   
        }
        .sideNavbuttons ul li a i span{
            font-size:10px;
            margin-left:25px;
        }
        .sideNavbuttons ul li a:hover{
            background-color:rgb(255, 255, 255);
            color:rgb(0, 9, 92);
        }

        .sideNavbuttons ul li a.active{
            background-color:rgb(255, 251, 251);
            color:rgb(0, 9, 92);
        }
        .logoutButton{
            width:100%;
            margin-top:30vh;
                  
        }
        .logoutButton:hover{
            background-color:white;
        }
        #logout{
            font-size: 12px;
           font-weight:bold;
        }
        .sideNavbuttons ul li a.active i {
            color:rgb(0, 9, 92);
        }

        .sideNavbuttons ul li a.active span {
            color:rgb(0, 9, 92);
        }

        /* FOR ADMIN DASHBOARD CONTAINER ONE*/
        .dashboardmainCon{
            width:100%;
            height:auto;
            
            
        }
        .topnavCon{
            width:100%;
            height:10vh;
            margin-left:73px;
            background-color: rgba(255, 255, 255, 0.171);
            position:fixed;   
            box-shadow: 3px 0px 10px rgba(0, 0, 0,10);
            overflow:hidden;
            z-index: 5; 
              
        }
        .dashboard{
            font-size:40px;
            font: size min 10px;   
            font-weight:bold;
            margin:20px 0px 0px 20px;  
            font-family: "kainit", sans-serif;
            display:inline-block;
        }
        .totalEnrolled{
            width:30vw;
            height:15vw;
            margin: 20vh 0px 0px 15vw;
            background-color: rgb(25, 118, 210);
            display:inline-block;
            text-align: center;
            box-shadow: 0px 10px 20px rgb(0, 0, 0);
        }
        .totalEnrollees{
            width:30vw;
            height:15vw;
            margin: 20vh 0px 0px 5vw;
            background-color: rgb(239, 83, 80);
            display:inline-block;
            text-align: center;
            box-shadow: 0px 10px 20px rgb(0, 0, 0);

        }
        .numTotal{
            font-size: 90px;
        }
        .txtTotal{
            font-size: 30px;
            font-weight:bold;
        }

        .chart-container {
            width: 80%;
            margin: auto;
            padding-top: 50px; /* Adjust as needed */
        }
        #courseChart{
            margin:15vh 0px 10vh 5vw;           
        }
        hr{
            border: 2px solid;
            color:black;
        }
       
       
       

     </style>


</head>
<body>
    
    <div class="sideNAvCon">
        <div class="logoCon">          
            <image src="../images/ITE_logo.png" id="iteLogo"/>
            <div id="admin">ADMIN</div>
        </div>
        <div class="sideNavbuttons">
            <ul>
                <li><a href="dashboard.php"><i class="fa-solid fa-gauge-high fa-xl" id="dashboardIcon"><span>Dasboard</span></i></a></li>
                <li><a href="courses.php"><i class="fa-solid fa-list fa-xl" id="classesIcon"><span>Courses</span></i></a></li>
                <li><a href="subjects.php"><i class="fa-solid fa-book fa-xl" id="subjectsIcon"><span>Subjects</span></i></a></li>
                <li><a href="students.php"><i class="fa-solid fa-users fa-xl" id="studentsIcon"><span>Students</span></i></a></li>
                <li><a href="enrollees.php"><i class="fa-solid fa-users-between-lines fa-xl" id="enrolleesIcon"><span>Enrollees</span></i></a></li>
                <li class="logoutButton">
                    <a href="logout.php"><i class="fa-solid fa-right-from-bracket fa-xl"><span id="logout">Logout</span></i></a>
                </li>
            </ul>
        </div>
    
    </div>    
    <div class="dashboardmainCon">        
        <div class="topnavCon">
            <div class="dashboard">DASHBOARD</div>
        </div> 
        <div>
        <?php

            include_once '../database.php';

            // Query to count total students in the studentmasterlist
            $countTotalEnrolledQuery = "SELECT COUNT(*) as total FROM studentsmasterlist  WHERE COURSE IN ('BS Computer Science', 'BS Information Technology','Associate in Computer Technology','Bachelor of Library and Information science')";
            $resultTotalEnrolled = mysqli_query($conn, $countTotalEnrolledQuery);
            if (!$resultTotalEnrolled) {
                die("Query failed: " . mysqli_error($conn));
            }
            $rowTotalEnrolled = mysqli_fetch_assoc($resultTotalEnrolled);
            $totalEnrolled = $rowTotalEnrolled['total'];

            // Query to count total enrollees
            $countTotalEnrolleesQuery = "SELECT COUNT(*) as total FROM enrollees WHERE COURSE IN ('BS Computer Science', 'BS Information Technology','Associate in Computer Technology','Bachelor of Library and Information science')";
            $resultTotalEnrollees = mysqli_query($conn, $countTotalEnrolleesQuery);
            if (!$resultTotalEnrollees) {
                die("Query failed: " . mysqli_error($conn));
            }
            $rowTotalEnrollees = mysqli_fetch_assoc($resultTotalEnrollees);
            $totalEnrollees = $rowTotalEnrollees['total'];

            echo "<div class='totalEnrolled'>
                    <p class='numTotal'> $totalEnrolled</p>
                    <p class='txtTotal'>Total Students</p>
                </div>";

            echo "<div class='totalEnrollees' id='totalEnrollees'>
                    <p class='numTotal'>$totalEnrollees</p>
                    <p class='txtTotal'>Total Enrollees </p>
                </div>";



                


        ?>
        </div>
        <hr>
        <div class="chart-container">
            <canvas id="courseChart"></canvas>
        </div>
       
        


    </div>


    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    fetch('data.php')
        .then(response => response.json())
        .then(data => {
            var ctx = document.getElementById('courseChart').getContext('2d');
            var courseChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: ['BSCS', 'BSIT', 'ACT', 'BLIS'],
                    datasets: [{
                        label: 'Number of Enrolled Students',
                        data: [data.BSCS, data.BSIT, data.ACT, data.BLIS],
                        backgroundColor: 'rgba(54, 162, 235)',
                        borderColor: 'rgba(54, 162, 235, 1)',
                        borderWidth: 2
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    },
                    plugins: {
                        legend: {
                            labels: {
                                font: {
                                    size: 20,
                                    weight: 'bold'
                                }
                            }
                        }
                    }
                }
            });
        })
        .catch(error => console.error('Error fetching data:', error));
</script>

    
</body>
</html>