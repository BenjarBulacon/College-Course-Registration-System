<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <style>
        body {
            margin: 0px;
            padding: 0px;
            box-sizing: border-box;
        }

        /* FOR SIDE NAVIGATION */
        .sideNAvCon {
            height: 100vh;
            width: 73px;
            background-color: rgb(0, 9, 92);
            position: fixed;
            z-index: 10;
            top: 0;
            left: 0;
            box-shadow: 3px 0px 10px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            transition: width 0.3s ease;
        }
        .sideNAvCon:hover {
            width: 170px;
        }
        .logoCon {
            height: 100px;
            overflow: hidden;
            background-color: rgb(177, 177, 177);
        }
        #iteLogo {
            height: 60px;
            border-radius: 50%;
            margin: 10px 0px 0px 10px;
        }
        #admin {
            font-weight: bold;
            font-family: "kainit", sans-serif;
            margin: 0px 0px 0px 10px;
        }
        .sideNavbuttons {
            height: auto;
            width: auto;
        }
        .sideNavbuttons ul {
            list-style: none;
            margin-left: -50px;
        }
        .sideNavbuttons ul li {
            padding: 20px 0px 20px 15px;
            cursor: pointer;
            color: rgb(255, 255, 255);
        }
        .sideNavbuttons ul li a {
            color: white;
            padding: 20px 40px 20px 30px;
            width: 100%;
        }
        .sideNavbuttons ul li a i span {
            font-size: 10px;
            margin-left: 25px;
        }
        .sideNavbuttons ul li a:hover {
            background-color: rgb(255, 255, 255);
            color: rgb(0, 9, 92);
        }
        .sideNavbuttons ul li a.active {
            background-color: rgb(255, 251, 251);
            color: rgb(0, 9, 92);
        }
        .logoutButton {
            width: 100%;
            margin-top: 30vh;
        }
        .logoutButton:hover {
            background-color: white;
        }
        #logout {
            font-size: 12px;
            font-weight: bold;
        }
        .sideNavbuttons ul li a.active i {
            color: rgb(0, 9, 92);
        }
        .sideNavbuttons ul li a.active span {
            color: rgb(0, 9, 92);
        }

        /* FOR ADMIN DASHBOARD CONTAINER ONE */
        .topnavCon {
          
          width:100vw;
          height:10vh;
          background-color:rgb(236, 239, 250);
          box-shadow: 3px 0px 10px rgba(0, 0, 0,10);
        }
        .enrolleesmainCon {
            width: auto;
            height: 100vh;
            padding: 5vh 3vw 5vh 8vw;
            
            
        }       
        .enrolleestxt {
            font-size: 40px;
            font: size min 10px;
            font-weight: bold;
            margin: 10px 0px 0px 90px;
            font-family: "kainit", sans-serif;
            display: inline-block;
        }
        .table {
            text-align: center;
            width: 100%;
            border-collapse: collapse;
            box-shadow: 0px 10px 20px rgb(0, 0, 0);
            
        }
        .table tr th {
            border: 1px solid;
            padding: 5px;
            font-weight: bold;
            font-size: 15px;
            font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
        }
        .table tr td {
            border: 1px solid;           
        }
        .deleteIcon {
            width: 2vw;
            cursor: pointer;
        }
        .tblhead{
            border:2px solid;
        }

        /*FOR DELETING A ENROLLEES */
        .confirmation-popup {
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);           
        padding: 20px;
        z-index: 20;      
        width:100vw;
        height:100vh;
        background-color: rgba(0, 0, 0, 0.4);
        
    }
    

    .popup-content {
        text-align: center;
        width:30vw;
        height:30vh;
        background-color: whitesmoke;
        padding:8vh 5vw 5vh 5vw;
        border-radius: 20px;
        margin:30vh 0px 0px 35vw;
       
    }

    .popup-content p {
        margin-bottom: 20px;

    }

    .popup-content button {
        margin: 0 10px;
        padding: 5px 15px;
        cursor: pointer;
        border-radius: 10px;;
    }

    .popup-content button#confirm-yes {
        background-color: red;
        color: white;
        border: none;
    }

    .popup-content button#confirm-no {
        background-color: green;
        color: white;
        border: none;
    }
        
       
    </style>
</head>
<body>
    <div class="sideNAvCon">
        <div class="logoCon">          
            <img src="../images/ITE_logo.png" id="iteLogo" alt="ITE Logo"/>
            <div id="admin">ADMIN</div>
        </div>
        <div class="sideNavbuttons">
            <ul>
            <li><a href="dashboard.php"><i class="fa-solid fa-gauge-high fa-xl" id="dashboardIcon"><span>Dasboard</span></i></a></li>
                <li><a href="courses.php"><i class="fa-solid fa-list fa-xl" id="classesIcon"><span>Courses</span></i></a></li>
                <li><a href="subjects.php"><i class="fa-solid fa-book fa-xl" id="subjectsIcon"><span>Subjects</span></i></a></li>
                <li><a href="students.php"><i class="fa-solid fa-users fa-xl" id="studentsIcon"><span>Students</span></i></a></li>
                <li><a href="enrollees.php"><i class="fa-solid fa-users-between-lines fa-xl" id="enrolleesIcon"><span>Enrollees</span></i></a></li>
                <li class="logoutButton">
                    <a href="logout.php"><i class="fa-solid fa-right-from-bracket fa-xl"><span id="logout">Logout</span></i></a>
                </li>
            </ul>
        </div>
    </div>
    <div class="topnavCon">
        <div class="enrolleestxt">ENROLLEES</div>
    </div>    
        <div class="enrolleesmainCon">        
            <table class="table">
                <tr class="tblhead">
                    <th>Last Name</th>
                    <th>First Name</th>
                    <th>Middle Name</th>
                    <th>Gender</th>
                    <th>Birthdate</th>
                    <th>Email</th>
                    <th>Course</th>
                    <th>Year</th>
                    <th>Address</th>
                    <th>Guardian</th>
                    <th>Contact</th>
                </tr>

                <?php
                include '../database.php';

                $sql = "SELECT * FROM enrollees WHERE COURSE IN ('BS Computer Science', 'BS Information Technology','Associate in Computer Technology','Bachelor of Library and Information science')";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row["LASTNAME"] . "</td>";
                        echo "<td>" . $row["FIRSTNAME"] . "</td>";
                        echo "<td>" . $row["MIDDLENAME"] . "</td>";
                        echo "<td>" . $row["GENDER"] . "</td>";
                        echo "<td>" . $row["BIRTHDATE"] . "</td>";
                        echo "<td>" . $row["EMAIL"] . "</td>";
                        echo "<td>" . $row["COURSE"] . "</td>";
                        echo "<td>" . $row["YEAR"] . "</td>";
                        echo "<td>" . $row["ADDRESS"] . "</td>";
                        echo "<td>" . $row["GUARDIAN"] . "</td>";
                        echo "<td>" . $row["CONTACT"] . "</td>";    
                        echo "<td><img src='../images/delete.png' class='deleteIcon' data-student-id='" . $row['EMAIL'] . "'></td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='12'>No Enrollee's found </td></tr>";
                }
                $conn->close();
                ?>
            </table>
        </div>
     

    <script >

document.addEventListener('DOMContentLoaded', function() {
    const deleteIcons = document.querySelectorAll('.deleteIcon');

    deleteIcons.forEach(icon => {
        icon.addEventListener('click', function() {
            const studentId = this.getAttribute('data-student-id');
            showConfirmationPopup(studentId);
        });
    });
});

function showConfirmationPopup(studentId) {
    const confirmationPopup = document.createElement('div');
    confirmationPopup.classList.add('confirmation-popup');
    confirmationPopup.innerHTML = `
    
        <div class="popup-content">
            <p>Are you sure you want to delete this?</p>
            <button id="confirm-yes">Yes</button>
            <button id="confirm-no">No</button>
        </div>
    
    `;
    document.body.appendChild(confirmationPopup);

    document.getElementById('confirm-yes').addEventListener('click', function() {
        deleteStudent(studentId);
    });

    document.getElementById('confirm-no').addEventListener('click', function() {
        document.body.removeChild(confirmationPopup);
    });
}

function deleteStudent(studentId) {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'delete_enrollees.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onreadystatechange = function() {
        if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
            location.reload();
        }
    };
    xhr.send('student_id=' + studentId);
}



    </script>
</body>
</html>
