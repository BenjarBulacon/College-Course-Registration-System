<?php
include_once '../database.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $studentId = $_POST['studentId'];
    
    // Prepare and bind
    $stmt = $conn->prepare("DELETE FROM studentsmasterlist WHERE STUDENT_ID = ?");
    $stmt->bind_param("s", $studentId);
    
    // Execute the statement
    if ($stmt->execute()) {
        echo "Student deleted successfully.";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close the statement
    $stmt->close();
    $conn->close();
}
?>
