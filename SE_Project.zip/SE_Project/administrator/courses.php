<?php
    // Include database connection
    include '../database.php';

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Get form data
        $title = $_POST['title'];
        $id = $_POST['id'];
        $description = $_POST['description'];
        

        // Prepare and bind
        $stmt = $conn->prepare("INSERT INTO courses (TITLE, ID, DESCRIPTION) VALUES (?, ?, ?)");
        $stmt->bind_param("sss",  $title, $id, $description);

        // Execute the statement
        if ($stmt->execute()) {
            echo "";
        } else {
            echo "Error: " . $stmt->error;
        }

        // Close the statement
        $stmt->close();
    }

    // Fetch subjects from the database
    $result = $conn->query("SELECT * FROM courses");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" 
    integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
     crossorigin="anonymous" referrerpolicy="no-referrer" />



     <style>
        body{
            margin: 0px;
            padding:0px;
            box-sizing: border-box;
        }

        /* FOR SIDE NAVIGATION*/
        .sideNAvCon{
            height:100vh;
            width: 73px;
            background-color:rgb(0, 9, 92);   
            position:fixed;
            z-index:10;
            top: 0;
            left: 0;
            box-shadow: 3px 0px 10px rgba(0, 0, 0,10);
            overflow:hidden; 
            transition: width 0.3s ease;     
        }
        .sideNAvCon:hover{
            width:170px;
            
        }
        .logoCon{
            height:100px;
            overflow:hidden;
            background-color: rgb(177, 177, 177);
        }
        #iteLogo{
            height:60px;
            border-radius:50%;
            margin:10px 0px 0px 10px;
        }
        #admin{
            font-weight:bold;
            font-family: "kainit", sans-serif;
            margin:0px 0px 0px 10px;
        }
        .sideNavbuttons{
            height:auto;
            width:auto;
        }
        .sideNavbuttons ul{
            list-style: none;
            margin-left:-50px;
        }
        .sideNavbuttons ul li{
            padding:20px 0px 20px 15px; 
            cursor: pointer;  
            color:rgb(255, 255, 255);
        }
        .sideNavbuttons ul li a{
            color:white;
            padding:20px 40px 20px 30px ;
            width:100%;   
        }
        .sideNavbuttons ul li a i span{
            font-size:10px;
            margin-left:25px;
        }
        .sideNavbuttons ul li a:hover{
            background-color:rgb(255, 255, 255);
            color:rgb(0, 9, 92);
        }

        .sideNavbuttons ul li a.active{
            background-color:rgb(255, 251, 251);
            color:rgb(0, 9, 92);
        }
        .logoutButton{
            width:100%;
            margin-top:30vh;
                  
        }
        .logoutButton:hover{
            background-color:white;
        }
        #logout{
            font-size: 12px;
           font-weight:bold;
        }
        .sideNavbuttons ul li a.active i {
            color:rgb(0, 9, 92);
        }

        .sideNavbuttons ul li a.active span {
            color:rgb(0, 9, 92);
        }

        /* FOR TOP NAVIGATION*/ 
        .topNavCon{
            width:100vw;
            height:10vh;
            background-color:rgb(236, 239, 250);
            box-shadow: 3px 0px 10px rgba(0, 0, 0,10);
        }
        .subjectstxt{
            font-size:40px;
            margin:auto;
            font-weight:bold;
            font-family: "kainit", sans-serif;
            margin:0px 0px 0px 75px;
            padding:20px;
            display:inline-block;
        }
        .addbutton{
            padding:5px 10px 5px 10px;
            background-color: rgb(202, 202, 202);
            color:rgb(0, 42, 180);
            position:relative;
            border-radius: 50%;
            font-size:40px;
            float:right;
            margin-right:5vw;
            margin-top:10px;
            cursor:pointer;            
        }
        .addbutton:hover{
            box-shadow: 0px 0px 3px rgb(0, 9, 92);
            color:rgb(0, 119, 255);
        }
        .formCon{
            width:0px;
            height:0px;
           
            margin:2vh 0px 0px 7vw;
            background-color:rgba(194, 190, 190, 0.664);
            box-shadow: 0px 10px 20px rgba(0, 0, 0,10);
            border-radius: 10px;                       
            overflow:hidden;
            z-index:10;
            transition: width 0.5s, height 0.5s;
           
        }
        .formtitle{
            width:100%;
            height:6vh;  
            background-color:white;
            text-align:center;
            font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
            font-size:35px;
            font-weight:bold;
            display:inline-block;
        }
        .exitCon{
            float:right;
            margin-right:20px;
            cursor:pointer;
        }
        .formCon form{
            padding:20px 0px 20px 50px ;
        }
        .exitCon:hover{
            color:red;
        }
        .formCon form div{
            display:block;
            margin-top:20px;
        }
        .formCon form div label{
            display:inline-block;
            font-weight:bold;
            font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
            font-size: 20px;
        }
        .formCon form div input{
            display:inline-block;    
        }
        #title{
            width:40vw;
            height:4vh;
            border-radius:5px;
            margin-left:9vw;
        }
        #id{
            width:40vw;
            height:4vh;
            border-radius:5px;
            margin-left:12vw;
        }
        #description{
            width:40vw;
            height:10vh;
            border-radius:5px;
            margin-left:3vw;

        }
       
        #add{
            padding:5px;
            font-size:25px;
            border-radius:10px;
            font-weight:bold;
            font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
            width:15vw;
            height:6vh;
            margin:8vh 0px 0px 25vw;
        }

        /* Grid for courses */
        .grid-container {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            padding: 20px;
            margin-left: 75px;
            background-color: rgb(255, 255, 255);
            width: calc(100vw - 75px);
        }
        .grid-item {
            margin:auto;
            background-color:rgb(101, 145, 196);
            border: 1px solid #ccc;
            padding: 20px;           
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 70vw;
            box-shadow: 0px 0px 5px rgb(4, 159, 230);
            transition: 0.3s ease
        }
        .grid-item:hover{
            width: 80vw;

        }
        .grid-item h3 {
            margin: 10px 0;
            font-size:30px;
            font-weight: bold;
            text-align: center;
            font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
        }
        .grid-item p {
            margin: 5px 0;
        }
        .id{
            text-align:center;
        }


       
       
        
    </style>


    

</head>
<body>


    
    <div class="sideNAvCon">
        <div class="logoCon">          
            <image src="../images/ITE_logo.png" id="iteLogo"/>
            <div id="admin">ADMIN</div>
        </div>
        <div class="sideNavbuttons">
            <ul>
                <li><a href="dashboard.php"><i class="fa-solid fa-gauge-high fa-xl" id="dashboardIcon"><span>Dasboard</span></i></a></li>
                <li><a href="courses.php"><i class="fa-solid fa-list fa-xl" id="classesIcon"><span>Courses</span></i></a></li>
                <li><a href="subjects.php"><i class="fa-solid fa-book fa-xl" id="subjectsIcon"><span>Subjects</span></i></a></li>
                <li><a href="students.php"><i class="fa-solid fa-users fa-xl" id="studentsIcon"><span>Students</span></i></a></li>
                <li><a href="enrollees.php"><i class="fa-solid fa-users-between-lines fa-xl" id="enrolleesIcon"><span>Enrollees</span></i></a></li>
                <li class="logoutButton">
                    <a href="logout.php"><i class="fa-solid fa-right-from-bracket fa-xl"><span id="logout">Logout</span></i></a>
                </li>
            </ul>
        </div>
    
    </div>  
    
    
    <div class="subjectsmainCon">
        <div class="topNavCon">
            <div class="subjectstxt">COURSES </div>
            <div class="addbutton" id="addbutton"><i class="fa-solid fa-plus"></i></div>
        </div>    
    </div>

    <div class="formCon" id="formCon">
        <div class="formtitle">ADD COURSE
            <div class="exitCon" id="exitCon"><i class="fa-solid fa-xmark"></i></div>
        </div>
        <form action="courses.php" method="post">
            <div>
                <label for="title">TITLE</label>
                <input type="text" name="title" id="title" required>
            </div>
            <div>
                <label for="id">ID</label>
                <input type="text" name="id" id="id" required>
            </div>
            <div>
                <label for="description">DESCRIPTION</label>
                <input type="text" name="description" id="description" required>
            </div>
            
            <input type="submit" name="add" value="add" id="add">
        </form>
    </div>


   


    <div class="grid-container">
        <?php
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<div class='grid-item'>";
                echo "<h3>" . $row['TITLE'] . "</h3>";
                echo "<p class='id'>ID: " . $row['ID'] . "</p>";
                echo "<p>" . $row['DESCRIPTION'] . "</p>";
                echo "</div>";
            }
        } else {
            echo "<p>No courses found.</p>";
        }
        $conn->close();
        ?>
    </div>
















    <script>
        document.getElementById("addbutton").addEventListener("click", function() {
            document.getElementById("formCon").style.width = "90vw";
            document.getElementById("formCon").style.height = "80vh";
        });

        document.getElementById("exitCon").addEventListener("click", function() {
            document.getElementById("formCon").style.width = "0px";
            document.getElementById("formCon").style.height = "0px";
        });      
    </script>
    

    
    

    




    <script src="admin.js"></script>  


    
</body>
</html>