<?php
include_once '../database.php';

$query = "
    SELECT 
        COURSE,
        COUNT(*) as total 
    FROM 
        studentsmasterlist 
    WHERE 
        COURSE IN ('BS Computer Science', 'BS Information Technology', 'Associate in Computer Technology', 'Bachelor of Library and Information science')
    GROUP BY 
        COURSE
";

$result = mysqli_query($conn, $query);
if (!$result) {
    die("Query failed: " . mysqli_error($conn));
}

$data = [
    'BSCS' => 0,
    'BSIT' => 0,
    'ACT' => 0,
    'BLIS' => 0
];

while ($row = mysqli_fetch_assoc($result)) {
    switch ($row['COURSE']) {
        case 'BS Computer Science':
            $data['BSCS'] = $row['total'];
            break;
        case 'BS Information Technology':
            $data['BSIT'] = $row['total'];
            break;
        case 'Associate in Computer Technology':
            $data['ACT'] = $row['total'];
            break;
        case 'Bachelor of Library and Information science':
            $data['BLIS'] = $row['total'];
            break;
    }
}

header('Content-Type: application/json');
echo json_encode($data);
?>