<?php

function startsession(){
    session_start();
    if (isset($_SESSION["login"])) {
   header("Location: dashboard.php");
   die();
    }
}


require '../database.php';

if (isset($_POST["login"])) {
    $email = $_POST["email"];
    $password = $_POST["password"];

    // Prepare and bind
    $stmt = $conn->prepare("SELECT * FROM administrator WHERE EMAIL = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    if ($result->num_rows > 0) {
        if ($password == $row["PASSWORD"]) { // It's recommended to use password hashing
            startsession();
            $_SESSION["login"] = "true";
            $_SESSION["id"] = $row["ID"];
            header("Location: dashboard.php");
            
            die();
        } else {
            $error_message = "Password does not match";
        }
    } 
    else {
        $error_message = "Invalid email or password";
    }

    // Close the statement and the connection
    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link rel="stylesheet" href="students.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;500;700;900&family=Sen:wght@400;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css" />
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url("../images/rmmcbg.jpg");
            background-repeat: no-repeat;
            background-size: cover;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            height: 100vh;
        }
        .header {
            position: fixed;
            width: 100%;
            height: 10vh;
            overflow: hidden;
            background-color: white;
            margin-top: 0px;
        }
        .logoCon {
            float: left;
            width: auto;
            height: auto;
        }
        .logo {
            height: 10vh;
            width: 25vw;
        }
        .studentAdminCon {
            width: auto;
            height: auto;
            display: inline-block;
            text-align: center;
            margin: 15px 0px 0px 10vw;
            padding: 15px;
        }
        .studentButton, .adminButton {
            display: inline-block;
        }
        .studentAdminCon ul {
            list-style: none;
        }
        .studentAdminCon ul li a {
            text-decoration: none;
            margin-left: 10px;
            padding: 10px;
            color: rgb(4, 64, 177);
            border-radius: 10px;
            font-weight: bold;
            font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
        }
        .studentAdminCon ul li a:hover {
            background-color: antiquewhite;
        }
        .loginFormCon {
            margin-top: 15vh;
            width: 40vw;
            height: 70vh;
            justify-content: center;
            text-align: center;
            box-shadow: 0px 10px 20px rgba(0, 0, 0, 10);
            border-radius: 10px;
            background-color: rgba(192, 192, 192, 0.76);
        }
        .logintxt {
            text-align: center;
            font-size: 35px;
            font-weight: bold;
            font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
            margin: 20px 0px 0px 0px;
        }
        .usernameCon {
            margin-top: 5vh;
            width: auto;
            height: auto;
            justify-content: center;
        }
        .usernameCon label {
            display: block;
        }
        #email {
            height: 40px;
            width: 20vw;
            border-radius: 10px;
            margin-top: 10px;
        }
        .passwordCon {
            margin-top: 40px;
        }
        .passwordCon label {
            display: block;
        }
        #password {
            height: 40px;
            width: 20vw;
            border-radius: 10px;
            margin-top: 10px;
            border: 0px;
        }
        #login {
            width: 11vw;
            height: 40px;
            margin-top: 80px;
            border-radius: 15px;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="logoCon">
            <a href="../main.html"><img class="logo" src="../images/rmmcLogo.png" alt="RMMC Logo"></a>
        </div>
        <div class="studentAdminCon">
            <ul>
                <li class="studentButton"><a href="../students/studentlogin.php">STUDENT-LOGIN</a></li>
                <li class="adminButton"><a href="../administrator/adminlogin.php">ADMINISTRATOR</a></li>
            </ul>
        </div>
    </div>
    <div class="loginFormCon">
        <div class="logintxt">ADMIN LOGIN</div>
        <?php
        if (!empty($error_message)) {
            echo "<div class='alert alert-danger' id='errortxt'>$error_message</div>";
        }
        ?>
        <form action="adminlogin.php" method="post">
            <div class="usernameCon">
                <label for="email">Email</label>
                <input type="email" name="email" id="email" required>
            </div>
            <div class="passwordCon">
                <label for="password">Password</label>
                <input type="password" name="password" id="password" required>
            </div>
            <input type="submit" value="Login" name="login" id="login">
        </form>
    </div>
    <script src="home.js"></script>
</body>
</html>
