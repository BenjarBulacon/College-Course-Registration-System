document.addEventListener('DOMContentLoaded', function() {
  const navLinks = document.querySelectorAll('.sideNavbuttons ul li a');

  navLinks.forEach(link => {
      link.addEventListener('click', function(event) {
          

          // Remove 'active' class from all links
          navLinks.forEach(link => link.classList.remove('active'));

          // Add 'active' class to the clicked link
          this.classList.add('active');
      });
  });
});




// FOR STUDENTS


function addbutton(){
  document.getElementById('formCon').Style.display = "fixed";
}
function exitbutton(){
  document.getElementById('formCon').Style.display = "none";
}

addbtn = document.getElementById('addbutton');
exitbtn = document.getElementById('exitCon');

addbtn.addEventListener('click',addbutton);
exitbtn.addEventListener('click',exitbutton);