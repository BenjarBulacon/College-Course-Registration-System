<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Students</title>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" 
    integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
     crossorigin="anonymous" referrerpolicy="no-referrer" />
     
     <style>
        body{
            margin:0px;
            padding:0px;
        }
        /* FOR SIDE NAVIGATION*/
        .sideNAvCon{
            height:100vh;
            width:75px;
            background-color:rgb(0, 9, 92);   
            position:fixed;
            z-index:5;
            top: 0;
            left: 0;
            box-shadow: 3px 0px 10px rgba(0, 0, 0,10);
            overflow:hidden; 
            transition: width 0.3s ease;     
        }
        .sideNAvCon:hover{
            width:170px;
            
        }
        .logoCon{
            height:100px;
            overflow:hidden;
            background-color: #005797;
        }
        #iteLogo{
            height:60px;
            border-radius:50%;
            margin:10px 0px 0px 10px;
        }
        #admin{
            font-weight:bold;
            font-family: "kainit", sans-serif;
            margin:0px 0px 0px 10px;
        }
        .sideNavbuttons{
            height:auto;
            width:auto;
        }
        .sideNavbuttons ul{
            list-style: none;
            margin-left:-50px;
        }
        .sideNavbuttons ul li{
            padding:20px 0px 20px 15px; 
            cursor: pointer;  
            color:rgb(255, 255, 255);
        }
        .sideNavbuttons ul li a{
            color:white;
            padding:20px 40px 20px 30px ;
            width:100%;   
        }
        .sideNavbuttons ul li a i span{
            font-size:10px;
            margin-left:25px;
        }
        .sideNavbuttons ul li a:hover{
            background-color:rgb(255, 255, 255);
            color:rgb(0, 9, 92);
        }

        .sideNavbuttons ul li a.active{
            background-color:rgb(255, 251, 251);
            color:rgb(0, 9, 92);
        }
        .logoutButton{
            width:100%;
            margin-top: 30vh;
                  
        }
        .logoutButton:hover{
            background-color:white;
        }
        #logout{
            font-size: 12px;
           font-weight:bold;
        }
        .sideNavbuttons ul li a.active i {
            color:rgb(0, 9, 92);
        }

        .sideNavbuttons ul li a.active span {
            color:rgb(0, 9, 92);
        }

        /*FOR STUDENT MAIN CONTAINER*/
        .studentmainCon{
            width:100vw;
            height:100vh;
            
        }
        /* FOR TOP NAVIGATION*/ 
        .topNavCon{
            width:100vw;
            height:10vh;
            background-color:rgb(236, 239, 250);
            box-shadow: 3px 0px 10px rgba(0, 0, 0,10);

        }
        .studenttxt{
            font-size:40px;
          
            font-weight:bold;
            font-family: "kainit", sans-serif;
            margin:0px 0px 0px 75px;
            padding:20px;
            display:inline-block;
            
        }
        .addbutton{
            padding:5px 10px 5px 10px;
            background-color: rgb(202, 202, 202);
            color:rgb(0, 42, 180);
            position:relative;
            border-radius: 50%;
            font-size:40px;
            float:right;
            margin-right:5vw;
            margin-top:10px;
            cursor:pointer;            
        }
        .addbutton:hover{
            box-shadow: 0px 0px 3px rgb(0, 9, 92);
            color:rgb(0, 119, 255);
        }

        /*FOR ADD STUDENTS FORM*/
        .formCon{           
            width:0px;
            height:0px;         
            margin:5vh 0px 0px 10vw;
            border-top:1px solid;
            background-color:rgba(194, 190, 190, 0.664);
            box-shadow: 0px 10px 20px rgba(0, 0, 0,10);
            border-radius: 10px;                       
            overflow:hidden;
            z-index:10;            
            transition: width 0.5s, height 0.5s;
        }
        .formtitle{
            width:100%;
            height:7vh;
            background-color:white;
            text-align:center;
            font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
            font-size:40px;
            font-weight:bold;
            display:inline-block;
        }
        .exitCon{
           float:right;
           margin-right:20px;
           cursor:pointer;
        }
        .exitCon:hover{
            color:red;
        }
        form{
            padding:20px 20px 20px 40px ;
        }
        
        h5, .lnameCon, .fnameCon, .mnameCon {
            display:inline-block;
        }
        .lnameCon{
            margin-left:50px;
        }
        .lnameCon label, .fnameCon label, .mnameCon label{
            display:block;            
        }
        .nameinput{
            display:block;
            height:25px;
            width:18vw;           
        } 
        #firstname, #midname, .label{
            margin-left:29px;
        }
        #address{
            height:30px;
            width:60vw;
            margin:0px 0px 0px 60px;
        }
        #birthdate{
            margin:0px 0px 0px 50px;
            display:inline-block;
            height:30px;
            width:20vw;

        }
        
        .genCon{
            margin:0px 0px 0px 60px;
            display:inline-block;
        }
        #female{
            margin:0px 0px 0px 50px;
        }
        #email{
            margin:0px 0px 0px 80px;
            height:30px;
            width:60vw;
        }
        #course{
            margin:0px 0px 0px 70px;
            height:30px;
            width:30vw;
        }
        .yearCon{
            display:inline-block;
            margin-left:50px;
        }
        #year{
            margin:0px 0px 0px 20px;
            height:30px;
            width:10vw;
        }
        .idCon h5{
            font-size:15px;
            

        }
        #idnumber{
            height:30px;
            width:30vw;
            margin:0px 0px 0px 40px;

        }    
        #submit{
            height:40px;
            width:250px;
            font-size:25px;
            margin: 40px 0px 0px 30vw;
        }
        .dataDisplay{
            width:80vw;
            height:auto;
            background-color:grey;
            margin:3vh 0px 0px 9vw;
            position: relative;
            z-index:2;
            padding:20px;
            background-color:rgb(235, 236, 241);
            box-shadow: 1px 0px 2px rgba(0, 0, 0,10);
        }
        .table{
            text-align:center;
            width:100%;
            border-collapse: collapse;

        }
        .table tr th{
            border:1px solid;
            padding:10px;
            font-weight:bold;
            font-size:20px;
            font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;

        }
        .table tr td{
            border:1px solid;
            padding:5px;
        }
        .editIcon{
            width:2vw;
            cursor:pointer;

        }
        .deleteIcon{
            width:2vw;
            cursor:pointer;

        }

        /* Confirmation Popup */
        .popup {
            position: fixed;
            display: none;          
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background-color: rgba(0,0,0,0.5);
            justify-content: center;
            align-items: center;
            z-index: 10;
           
        }
        .popup-content {
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            text-align: center;            
            width:30vw;
            height:30vh;
            
        }
        .popup-buttons {
            display: flex;            
            margin-top: 80px;
            justify-content: center;
          
            
        }
        .popup-buttons button {
            margin: 0 10px;
            padding: 5px 15px;
            cursor: pointer;
            border-radius: 5px;
            
        }
        #confirmDelete{
            width:8vw;
            height:5vh;
            border-radius:20px;
            display:inline-block;
           
           
        }
        #cancelDelete{
            width:8vw;
            height:5vh;
            border-radius:20px;
            display:inline-block;
           

        }
        


    </style>
</head>
<body>

    <?php

    include_once '../database.php';


    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Get form data
        $lastname = $_POST['lastname'];
        $firstname = $_POST['firstname'];
        $midname = $_POST['midname'];
        $address = $_POST['address'];
        $birthdate = $_POST['birthdate'];
        $gender = isset($_POST['gender']) ? $_POST['gender'] : ''; // Check if gender is set
        $email = $_POST['email'];
        $course = $_POST['course'];
        $year = $_POST['year'];
        $idnumber = $_POST['idnumber'];
    
        // Prepare and bind
        $stmt = $conn->prepare("INSERT INTO studentsmasterlist (STUDENT_ID, LASTNAME, FIRSTNAME, MIDDLENAME, GENDER, COURSE, YEAR, EMAIL, ADDRESS, BIRTHDATE) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssssssss", $idnumber, $lastname, $firstname, $midname, $gender, $course, $year, $email, $address, $birthdate);
     
        // Execute the statement
        if ($stmt->execute()) {
            $lastname = $firstname = $midname = $address = $birthdate = $gender = $email = $course = $year = $idnumber = '';
        } else {
            echo "Error: " . $stmt->error;
        }

        // Close the statement
        $stmt->close();
            
    }

    $sql = "SELECT  STUDENT_ID, CONCAT(LASTNAME, ' ', FIRSTNAME, ' ', MIDDLENAME) AS FULLNAME, COURSE, YEAR, EMAIL FROM studentsmasterlist";
    $result = $conn->query($sql);
    
    ?>



    
    <div class="sideNAvCon">
        <div class="logoCon">          
            <image src="../images/ITE_logo.png" id="iteLogo"/>
            <div id="admin">ADMIN</div>
        </div>
        <div class="sideNavbuttons">
            <ul>
                <li><a href="dashboard.php"><i class="fa-solid fa-gauge-high fa-xl" id="dashboardIcon"><span>Dasboard</span></i></a></li>
                <li><a href="courses.php"><i class="fa-solid fa-list fa-xl" id="classesIcon"><span>Courses</span></i></a></li>
                <li><a href="subjects.php"><i class="fa-solid fa-book fa-xl" id="subjectsIcon"><span>Subjects</span></i></a></li>
                <li><a href="students.php"><i class="fa-solid fa-users fa-xl" id="studentsIcon"><span>Students</span></i></a></li>
                <li><a href="enrollees.php"><i class="fa-solid fa-users-between-lines fa-xl" id="enrolleesIcon"><span>Enrollees</span></i></a></li>        
                <li class="logoutButton">
                    <a href="logout.php"><i class="fa-solid fa-right-from-bracket fa-xl"><span id="logout">Logout</span></i></a>
                </li>
            </ul>
        </div>
    </div>

    <div class="studentmainCon">
        <div class="topNavCon">
            <div class="studenttxt">STUDENTS ENROLLED </div>
            <div class="addbutton" id="addbutton"><i class="fa-solid fa-plus"></i></div>
        </div> 
        



   
        <div class="formCon" id="formCon">
            <div class="formtitle">ADD STUDENT
                <div class="exitCon" id="exitCon"><i class="fa-solid fa-xmark" ></i></div>
            </div>
            
            
            <form action="students.php" method="post" id="addStudentForm">
                <div class="fullnameCon">
                    <h5>FULL NAME</h5>
                    <div class="lnameCon">
                        <label>Last Name</label>
                        <input type="text" name="lastname" id="lastname" class="nameinput" required>
                    </div>
                    <div class="fnameCon">
                        <label class="label">First Name</label>
                        <input type="text" name="firstname" id="firstname" class="nameinput" required>
                    </div>
                    <div class="mnameCon">
                        <label class="label">Middle Name</label>
                        <input type="text" name="midname" id="midname" class="nameinput" required>
                    </div>
                </div>
                <div class="addressCon">
                    <h5>ADDRESS</h5>
                    <input type="text" name="address" id="address" placeholder="city/brgy/prk/blck" required>
                </div>
                <div class="brithdateCon">
                    <h5>BIRTHDATE</h5>
                    <input type="date" name="birthdate" id="birthdate" required>
                </div>
                <div class="genderCon">
                    <h5>GENDER</h5>
                    <div class="genCon">
                        <input type="radio" name="gender" id="male">
                        <label for="male">Male</label>
    
                        <input type="radio" name="gender" id="female">
                        <label for="female">Female</label>
                    </div>
                </div>
                <div class="email">
                    <h5>EMAIL</h5>
                    <input type="email" name="email" id="email" required>
                </div>
                <div class="courseCon">
                    <h5>COURSE</h5>
                    <select id="course" name="course"  required>
                        <option></option>                       
                        <option>BS Computer Science</option>                                                                                             
                        <option>BS Information Technology</option>                                           
                        <option>Associate in Computer Technology</option>
                        <option>Bachelor in Library and Information science </option>
                        
                    </select>
                    
                    <div class="yearCon">
                        <label class="yeartxt">YEAR</label>
                        <select name="year" id="year">
                            <option>1</option>
                            <option>2</option>
                            <option>3</option>
                            <option>4</option>
                        </select>
                    </div>
                </div>
    
                <div class="idCon">
                    <h5>ID NUMBER</h5>                                            
                    <input type="text" name="idnumber" id="idnumber" required>        
                </div>
    
                <input type="submit" name="submit" id="submit" value="ADD">
            </form>
        </div>


        <div class="dataDisplay">    
    
    <table class="table">
        <tr>
            <th>ID Number</th>
            <th>Full Name</th>
            <th>Course</th>
            <th>Year</th>
            <th>Email</th>
        </tr>
        <?php
        // Fetch data from the database

                       
        if ($result->num_rows > 0) {
            // Output data of each row
            while($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row["STUDENT_ID"] . "</td>";
                echo "<td>" . $row["FULLNAME"] . "</td>";
                echo "<td>" . $row["COURSE"] . "</td>";
                echo "<td>" . $row["YEAR"] . "</td>";
                echo "<td>" . $row["EMAIL"] . "</td>";
                echo "<td><image src='../images/edit.png' class='editIcon' id='editIcon'></td>";
                echo "<td><img src='../images/delete.png' class='deleteIcon' data-student-id='" . $row['STUDENT_ID'] . "'></td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='5'>No records found</td></tr>";
        }
        $conn->close();
        ?>
    </table>
    </div>

    </div>

    <div class="popup" id="popup">
        <div class="popup-content">
            <p>Are you sure you want to delete this student?</p>
            <div class="popup-buttons">
                
                <button id="cancelDelete">No</button>               
                <button id="confirmDelete">Yes</button>
               
                
            </div>
        </div>
    </div>
  
    <script>
        


        document.getElementById("addbutton").addEventListener("click", function() {
            document.getElementById("formCon").style.width = " 80vw";
            document.getElementById("formCon").style.height = " 80vh";
            
            
        });

        document.getElementById("exitCon").addEventListener("click", function() {
            document.getElementById("formCon").style.width = "0px";
            document.getElementById("formCon").style.height = " 0px";
           
        });  


        document.getElementById('exitCon').addEventListener('click', function() {
            var formCon = document.getElementById('formCon');
            formCon.style.width = '0px';
            formCon.style.height = '0px';
        });

        document.addEventListener("DOMContentLoaded", function () {
            var deleteButtons = document.querySelectorAll('.deleteIcon');
            deleteButtons.forEach(function (button) {
                button.addEventListener('click', function () {
                    var studentId = button.getAttribute('data-student-id');
                    var popup = document.getElementById('popup');
                    
                    popup.style.display = 'flex';
                    document.getElementById('confirmDelete').setAttribute('data-student-id', studentId);
                });
            });

            document.getElementById('cancelDelete').addEventListener('click', function () {
                var popup = document.getElementById('popup');
                popup.style.display = 'none';
            });

            document.getElementById('confirmDelete').addEventListener('click', function () {
                var studentId = document.getElementById('confirmDelete').getAttribute('data-student-id');
                
                // Perform the delete operation using AJAX
                var xhr = new XMLHttpRequest();
                xhr.open("POST", "delete_student.php", true);
                xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                xhr.onreadystatechange = function () {
                    if (xhr.readyState === 4 && xhr.status === 200) {
                        // Handle the response from the server
                        alert(xhr.responseText);
                        location.reload(); // Reload the page after deletion
                    }
                };
                xhr.send("studentId=" + studentId);

                var popup = document.getElementById('popup');
                popup.style.display = 'none';
            });
        });


        // TO RESET THE FORM WHEN ITS SUBMITTED
        document.addEventListener("DOMContentLoaded", function () {
            // Handle form submission via AJAX
            document.querySelector('#studentForm').addEventListener('submit', function(event) {
                event.preventDefault();

                var formData = new FormData(this);

                var xhr = new XMLHttpRequest();
                xhr.open('POST', 'students.php', true);
                xhr.onreadystatechange = function () {
                    if (xhr.readyState === 4 && xhr.status === 200) {
                        var response = xhr.responseText;
                        if (response.trim() === 'success') {
                            alert('Data inserted successfully!');
                            document.getElementById('addStudentForm').reset();
                            // Optionally, reset form data variables here if needed
                        } else {
                            alert('Error: ' + response);
                        }
                    }
                };
                xhr.send(formData);
            });
        });
        
    

    
    </script>
</body>
</html>
